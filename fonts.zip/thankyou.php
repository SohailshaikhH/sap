<!DOCTYPE html>
<html lang="en">

<?php
include 'head.php'
    ?>
<header>
    <?php
    include 'header.php';
    ?>
</header>
<section>
    <p class="display-1">
        Thank u
    </p>
</section>

<footer>
    <?php
    include 'footer.php';
    ?>
</footer>


<?php
include 'script.php';
?>
</body>

</html>